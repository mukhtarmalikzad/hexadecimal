
package convertingdecimal.tohexadecimal;

public class ConvertingDecimalToHexadecimal {

    
    public static void main(String[] args) {
       int d=970;
       String digits="0123456789ABCDEF";
       if(d<=0){
           System.out.println("negative number are not allowed");
       }
       int base=16;
       String hex="";
       while(d>0){
           int digit=d%base;
           hex=digits.charAt(digit)+hex;
           d=d/base;
       }
        System.out.println("The hexa Decimal value in"+hex);;
    }
    
}
